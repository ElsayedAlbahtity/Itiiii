# IT Helpdesk RAG Assistant

A Retrieval-Augmented Generation (RAG) web application that answers employee
questions about internal IT helpdesk topics (password resets, VPN, printers,
mobile email setup, software requests, backup policy, Wi-Fi access) using
only a company knowledge base — with cited, grounded answers.

**Track:** Core Track (text-only RAG).

## Overview

The user asks a question in a chat-style web UI. The question is embedded and
matched against a vector store of knowledge-base article chunks. The most
relevant chunks are inserted into a prompt sent to a local LLM (via Ollama),
which answers strictly from that context and the UI displays the answer along
with which source article(s) it came from.

## Architecture

```
┌─────────────┐        HTTP POST /query        ┌───────────────────┐
│  Streamlit   │ ──────────────────────────────▶│   FastAPI backend  │
│  frontend    │                                 │  (app/main.py)     │
│ (chat UI)    │ ◀────────────────────────────── │                     │
└─────────────┘        {answer, sources}        │  ┌───────────────┐  │
                                                  │  │ retrieval.py  │  │
                                                  │  │ (Chroma +     │  │
                                                  │  │  embeddings)  │  │
                                                  │  └───────┬───────┘  │
                                                  │          │          │
                                                  │  ┌───────▼───────┐  │
                                                  │  │ generation.py │  │
                                                  │  │ (Ollama LLM)  │  │
                                                  │  └───────────────┘  │
                                                  └──────────┬──────────┘
                                                             │ loads at startup
                                                  ┌──────────▼──────────┐
                                                  │  data/vector_store/  │
                                                  │  (persisted Chroma   │
                                                  │  collection, built   │
                                                  │  by the notebook)    │
                                                  └───────────────────────┘
                                                             ▲
                                                  ┌──────────┴──────────┐
                                                  │ notebooks/           │
                                                  │ rag_pipeline.ipynb   │
                                                  │ (load → chunk →      │
                                                  │  embed → store →     │
                                                  │  evaluate)           │
                                                  └───────────────────────┘
```

## Tech Stack

| Layer | Technology |
|---|---|
| Notebook / pipeline | Python, pandas, scikit-learn (TF-IDF fallback) / sentence-transformers |
| Vector database | ChromaDB (persistent, on disk) |
| LLM | Ollama (local), e.g. `llama3.1` |
| Backend API | FastAPI, Pydantic v2, Uvicorn |
| Frontend | Streamlit (chat UI) |
| Testing | pytest, FastAPI `TestClient` |

## Project Structure

```
rag-assistant-project/
├── notebooks/
│   └── rag_pipeline.ipynb        # full pipeline: load, chunk, embed, store, retrieve, evaluate
├── data/
│   ├── raw/                      # 7 source .txt knowledge-base articles
│   └── vector_store/             # persisted Chroma collection + pipeline_config.json
├── backend/
│   ├── app/
│   │   ├── main.py               # FastAPI app, CORS, startup loading
│   │   ├── api/routes/query.py   # GET /health, POST /query
│   │   ├── core/config.py        # settings from .env
│   │   ├── schemas/query.py      # QueryRequest / QueryResponse
│   │   ├── services/
│   │   │   ├── retrieval.py      # loads vector store, retrieves chunks
│   │   │   └── generation.py     # calls Ollama LLM, builds answer
│   │   └── utils/logging_config.py
│   ├── data/vector_store/        # copy of the notebook's exported vector store
│   ├── tests/test_query.py
│   ├── requirements.txt
│   ├── .env.example
│   └── Dockerfile
├── frontend/
│   ├── app.py                    # Streamlit chat app
│   ├── api_client.py             # backend API wrapper
│   ├── .env.example
│   └── requirements.txt
├── .gitignore
└── README.md
```

## Domain & Data

The knowledge base is a small set of **7 synthetic IT helpdesk articles**
(plain text) covering: password resets, VPN setup, printer troubleshooting,
mobile email configuration, software request process, data backup policy,
and office Wi-Fi access. All files are text-extractable directly (no OCR
needed). To use a different or larger corpus, drop more `.txt`/`.pdf` files
into `data/raw/` and re-run the notebook.

> **Note on embeddings/LLM:** by default the notebook and backend run with a
> lightweight, fully offline **TF-IDF fallback embedder** and an extractive
> fallback answer generator, so the whole project runs with zero external
> downloads for grading/demo purposes. For the intended production setup,
> flip `USE_LOCAL_MODELS=true` (backend `.env`) / `USE_LOCAL_MODELS = True`
> (notebook) to use `sentence-transformers` embeddings and a local Ollama LLM
> — both code paths are already implemented in `retrieval.py`,
> `generation.py`, and the notebook.

## Setup & Run

### 0. Prerequisites
- Python 3.10+
- (Optional, for full LLM answers) [Ollama](https://ollama.com) installed and running: `ollama pull llama3.1`

### 1. Build the vector store (notebook)
```bash
cd notebooks
pip install jupyter pandas numpy chromadb scikit-learn pypdf nbformat
jupyter notebook rag_pipeline.ipynb
# Run all cells top to bottom (Kernel -> Restart & Run All)
```
This creates/refreshes `data/vector_store/`.

### 2. Backend
```bash
cd backend
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
cp -r ../data/vector_store ./data/vector_store       # if not already copied
uvicorn app.main:app --reload
# open http://localhost:8000/docs to try /query from Swagger UI
```

### 3. Frontend
```bash
cd frontend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
streamlit run app.py
# open http://localhost:8501
```

### 4. Tests
```bash
cd backend
pytest tests/ -v
```

## Environment Variables

### Backend (`backend/.env`)
| Variable | Default | Description |
|---|---|---|
| `VECTOR_STORE_PATH` | `./data/vector_store` | Path to the persisted Chroma collection |
| `COLLECTION_NAME` | `helpdesk_kb` | Chroma collection name |
| `USE_LOCAL_MODELS` | `false` | `true` to use sentence-transformers instead of the TF-IDF fallback |
| `EMBEDDING_MODEL_NAME` | `all-MiniLM-L6-v2` | Sentence-transformers model (when `USE_LOCAL_MODELS=true`) |
| `OLLAMA_MODEL_NAME` | `llama3.1` | Local Ollama model used for generation |
| `OLLAMA_HOST` | `http://localhost:11434` | Ollama server address |
| `TOP_K` | `3` | Number of chunks retrieved per query |
| `FRONTEND_ORIGIN` | `http://localhost:8501` | Allowed CORS origin |
| `LOG_LEVEL` | `INFO` | Logging verbosity |

### Frontend (`frontend/.env`)
| Variable | Default | Description |
|---|---|---|
| `API_BASE_URL` | `http://localhost:8000` | Backend base URL — never hard-coded in `app.py` |

## API Reference

### `GET /health`
Returns service status and how many chunks are indexed.

```bash
curl http://localhost:8000/health
```
```json
{"status": "ok", "collection_name": "helpdesk_kb", "chunks_indexed": 29}
```

### `POST /query`
```bash
curl -X POST http://localhost:8000/query \
  -H "Content-Type: application/json" \
  -d '{"question": "How do I set up VPN on a new laptop?"}'
```
```json
{
  "answer": "... grounded answer text ...",
  "sources": ["02_vpn_setup.txt"],
  "retrieved_chunks": [
    {"doc_id": "02_vpn_setup.txt", "chunk_id": "02_vpn_setup.txt::chunk_0", "snippet": "..."}
  ]
}
```
Invalid input (missing/empty `question`) returns `422 Unprocessable Entity`.

## Evaluation Results (Phase 2.6)

10 test questions were run through the pipeline; see
`data/vector_store/evaluation_results.csv` for the full table produced by the
notebook. Summary: **9/10 fully correct**, 1/10 mostly correct (see the
notebook's "Main failure cases" discussion for details on the one partial
case and how it's mitigated by switching on `USE_LOCAL_MODELS`).

## Screenshots

Captured from a live local run of the app (backend on :8000, frontend on :8501):

- `docs/screenshot_chat_empty.png` — Streamlit chat UI on load, showing the backend
  status sidebar ("Online — 29 chunks indexed")
- `docs/screenshot_chat_answer.png` — a real question asked in the chat
  ("How do I reset my corporate password?") with the grounded answer and its
  cited sources (`01_password_reset.txt`, `04_email_setup_mobile.txt`)
- `docs/openapi.json` — the live OpenAPI schema served at `/openapi.json`,
  confirming the `/health` and `/query` endpoints are registered. The
  Swagger UI at `/docs` renders this same schema visually and loads its
  styling from a public CDN, so grab a screenshot of `/docs` on your own
  machine (it renders instantly there) to include alongside these.

## Verified Locally

- [x] Notebook runs top-to-bottom with no errors (`Kernel -> Restart & Run All`)
- [x] `pytest tests/ -v` — 4/4 tests passing
- [x] Backend `/health` and `/query` tested live via `curl`
- [x] Frontend tested live against the running backend
- [x] Fresh-clone check: follow only this README from a clean folder

## Extending to the Extended Track (CV/YOLO)

This project is structured so the Extended Track can be added without a
rewrite:
- Add an image dataset under `data/images/`
- Add a `2.5 Vision Component` section to the notebook running/fine-tuning a
  YOLO model, and decide how detections feed into the RAG prompt context
- Add an image-upload field to `QueryRequest` (or a new endpoint) in the
  backend, and fuse detection output into `generation.py`'s prompt
- Add an image upload widget to `frontend/app.py` and display detection
  results next to the text answer
