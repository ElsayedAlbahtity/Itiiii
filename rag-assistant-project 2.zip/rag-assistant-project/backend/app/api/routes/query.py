import logging

from fastapi import APIRouter, HTTPException, Request

from app.core.config import settings
from app.schemas.query import HealthResponse, QueryRequest, QueryResponse, SourceChunk
from app.services.generation import generate_answer

logger = logging.getLogger("rag.api")
router = APIRouter()


@router.get("/health", response_model=HealthResponse)
def health(request: Request):
    retrieval_service = request.app.state.retrieval_service
    return HealthResponse(
        status="ok",
        collection_name=settings.collection_name,
        chunks_indexed=retrieval_service.chunk_count(),
    )


@router.post("/query", response_model=QueryResponse)
def query(payload: QueryRequest, request: Request):
    retrieval_service = request.app.state.retrieval_service

    try:
        hits = retrieval_service.retrieve(payload.question, top_k=payload.top_k)
    except Exception as exc:
        logger.exception("Retrieval failed")
        raise HTTPException(status_code=500, detail="Retrieval failed") from exc

    answer = generate_answer(payload.question, hits)
    sources = sorted({h["doc_id"] for h in hits})
    retrieved_chunks = [
        SourceChunk(doc_id=h["doc_id"], chunk_id=h["chunk_id"], snippet=h["text"][:200])
        for h in hits
    ]

    return QueryResponse(answer=answer, sources=sources, retrieved_chunks=retrieved_chunks)
