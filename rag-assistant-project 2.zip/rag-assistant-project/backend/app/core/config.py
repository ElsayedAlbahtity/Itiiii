"""Application settings, loaded from environment variables / .env file."""
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # Vector store
    vector_store_path: str = "./data/vector_store"
    collection_name: str = "helpdesk_kb"

    # Embeddings
    use_local_models: bool = False
    embedding_model_name: str = "all-MiniLM-L6-v2"

    # LLM (Ollama)
    ollama_model_name: str = "llama3.1"
    ollama_host: str = "http://localhost:11434"

    # Retrieval
    top_k: int = 3

    # CORS
    frontend_origin: str = "http://localhost:8501"

    # App
    app_name: str = "RAG Helpdesk Assistant API"
    log_level: str = "INFO"


settings = Settings()
