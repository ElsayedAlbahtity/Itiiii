from pydantic import BaseModel, Field


class QueryRequest(BaseModel):
    question: str = Field(..., min_length=1, description="The user's natural-language question.")
    top_k: int | None = Field(default=None, ge=1, le=10, description="Optional override for number of retrieved chunks.")


class SourceChunk(BaseModel):
    doc_id: str
    chunk_id: str
    snippet: str


class QueryResponse(BaseModel):
    answer: str
    sources: list[str]
    retrieved_chunks: list[SourceChunk] = []


class HealthResponse(BaseModel):
    status: str
    collection_name: str
    chunks_indexed: int
