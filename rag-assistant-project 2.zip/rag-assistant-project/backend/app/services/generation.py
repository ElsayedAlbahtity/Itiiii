"""Builds the grounded prompt and calls the local Ollama LLM to generate
an answer. Falls back to an extractive template if Ollama is not reachable
(e.g. it isn't installed/running yet), so the API stays usable during setup.
"""
import logging
import re

from app.core.config import settings

logger = logging.getLogger("rag.generation")

PROMPT_TEMPLATE = """You are an internal IT helpdesk assistant. Answer the
user's question using ONLY the context below. If the answer is not contained
in the context, say you don't have that information instead of guessing.
Be concise and reference which article the information came from.

Context:
{context}

Question: {question}

Answer:"""


def build_prompt(question: str, hits: list[dict]) -> str:
    context = "\n\n".join(f"[{h['doc_id']}] {h['text']}" for h in hits)
    return PROMPT_TEMPLATE.format(context=context, question=question)


def _fallback_extractive_answer(hits: list[dict]) -> str:
    """Used only if Ollama is unreachable, so the API never hard-fails."""
    if not hits:
        return "I don't have that information in the knowledge base."
    sentences = re.split(r"(?<=[.!?])\s+", hits[0]["text"])
    return " ".join(sentences[:2]).strip()


def generate_answer(question: str, hits: list[dict]) -> str:
    if not hits:
        return "I don't have that information in the knowledge base."

    prompt = build_prompt(question, hits)

    try:
        import ollama

        client = ollama.Client(host=settings.ollama_host)
        response = client.chat(
            model=settings.ollama_model_name,
            messages=[{"role": "user", "content": prompt}],
        )
        return response["message"]["content"].strip()
    except Exception as exc:
        logger.warning(
            "Ollama call failed (%s). Falling back to extractive answer. "
            "Make sure `ollama serve` is running and the model is pulled "
            "(`ollama pull %s`).",
            exc,
            settings.ollama_model_name,
        )
        return _fallback_extractive_answer(hits)
