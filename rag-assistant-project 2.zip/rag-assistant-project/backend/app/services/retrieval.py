"""Loads the persisted vector store (built by the notebook) and retrieves
relevant chunks for a given question. Loaded ONCE at app startup, not per request.
"""
import json
import logging
from pathlib import Path

import chromadb

from app.core.config import settings

logger = logging.getLogger("rag.retrieval")


class Embedder:
    """Wraps whichever embedding backend the notebook was configured with.

    IMPORTANT: this must use the SAME embedding model/strategy that produced
    the vectors stored in the collection, or similarity scores will be
    meaningless. The model name used is read from pipeline_config.json,
    which the notebook writes at export time.
    """

    def __init__(self, use_local_models: bool, model_name: str, vector_store_path: Path):
        self.use_local_models = use_local_models
        self.model_name = model_name
        if use_local_models:
            from sentence_transformers import SentenceTransformer
            self._model = SentenceTransformer(model_name)
        else:
            # Rebuild the same TF-IDF vectorizer fit on the same corpus the
            # notebook used, so query vectors land in the same space as the
            # stored chunk vectors. In production (use_local_models=True)
            # this whole branch is skipped in favor of a proper sentence
            # embedding model, which does not need corpus refitting.
            from sklearn.feature_extraction.text import TfidfVectorizer

            client = chromadb.PersistentClient(path=str(vector_store_path))
            collection = client.get_collection(settings.collection_name)
            all_docs = collection.get(include=["documents"])["documents"]
            self._vectorizer = TfidfVectorizer(max_features=512)
            self._vectorizer.fit(all_docs)

    def embed(self, texts: list[str]):
        if self.use_local_models:
            return self._model.encode(texts, show_progress_bar=False).tolist()
        return self._vectorizer.transform(texts).toarray().astype(float).tolist()


class RetrievalService:
    def __init__(self):
        self.vector_store_path = Path(settings.vector_store_path)
        self.config = self._load_pipeline_config()

        self.client = chromadb.PersistentClient(path=str(self.vector_store_path))
        self.collection = self.client.get_collection(settings.collection_name)

        self.embedder = Embedder(
            use_local_models=self.config.get("use_local_models", settings.use_local_models),
            model_name=self.config.get("embedding_model", settings.embedding_model_name),
            vector_store_path=self.vector_store_path,
        )
        logger.info(
            "RetrievalService ready: %d chunks indexed in collection '%s'",
            self.collection.count(),
            settings.collection_name,
        )

    def _load_pipeline_config(self) -> dict:
        config_path = self.vector_store_path / "pipeline_config.json"
        if config_path.exists():
            return json.loads(config_path.read_text())
        return {}

    def chunk_count(self) -> int:
        return self.collection.count()

    def retrieve(self, question: str, top_k: int | None = None) -> list[dict]:
        k = top_k or settings.top_k
        query_embedding = self.embedder.embed([question])[0]
        results = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=k,
        )
        hits = []
        for doc, meta, dist, cid in zip(
            results["documents"][0],
            results["metadatas"][0],
            results["distances"][0],
            results["ids"][0],
        ):
            hits.append({
                "chunk_id": cid,
                "doc_id": meta["doc_id"],
                "text": doc,
                "distance": dist,
            })
        return hits
