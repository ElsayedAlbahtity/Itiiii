from fastapi.testclient import TestClient

from app.main import app


def test_health_ok():
    with TestClient(app) as client:
        response = client.get("/health")
        assert response.status_code == 200
        body = response.json()
        assert body["status"] == "ok"
        assert body["chunks_indexed"] > 0


def test_query_happy_path():
    with TestClient(app) as client:
        response = client.post("/query", json={"question": "How do I reset my password?"})
        assert response.status_code == 200
        body = response.json()
        assert "answer" in body
        assert isinstance(body["sources"], list)
        assert len(body["sources"]) > 0


def test_query_invalid_input_returns_422():
    with TestClient(app) as client:
        # Missing required "question" field
        response = client.post("/query", json={})
        assert response.status_code == 422


def test_query_empty_question_returns_422():
    with TestClient(app) as client:
        # Empty string violates min_length=1
        response = client.post("/query", json={"question": ""})
        assert response.status_code == 422
