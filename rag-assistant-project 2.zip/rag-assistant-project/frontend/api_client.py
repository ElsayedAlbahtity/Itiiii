"""Thin wrapper around the backend REST API. Reads the base URL from an
environment variable -- never hard-code it in the app.
"""
import os

import requests

API_BASE_URL = os.getenv("API_BASE_URL", "http://localhost:8000")
TIMEOUT_SECONDS = 30


class ApiError(Exception):
    pass


def check_health() -> dict:
    response = requests.get(f"{API_BASE_URL}/health", timeout=TIMEOUT_SECONDS)
    response.raise_for_status()
    return response.json()


def ask_question(question: str, top_k: int | None = None) -> dict:
    payload = {"question": question}
    if top_k:
        payload["top_k"] = top_k
    try:
        response = requests.post(f"{API_BASE_URL}/query", json=payload, timeout=TIMEOUT_SECONDS)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.ConnectionError as exc:
        raise ApiError(
            f"Could not reach the backend at {API_BASE_URL}. "
            "Is it running? (uvicorn app.main:app --reload)"
        ) from exc
    except requests.exceptions.HTTPError as exc:
        raise ApiError(f"Backend returned an error: {exc}") from exc
    except requests.exceptions.Timeout as exc:
        raise ApiError("The backend took too long to respond. Try again.") from exc
