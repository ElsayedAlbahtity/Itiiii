import streamlit as st

from api_client import API_BASE_URL, ApiError, ask_question, check_health

st.set_page_config(page_title="IT Helpdesk RAG Assistant", page_icon="🛠️")
st.title("🛠️ IT Helpdesk Assistant")
st.caption(f"Connected to backend: {API_BASE_URL}")

with st.sidebar:
    st.subheader("Backend status")
    try:
        health = check_health()
        st.success(f"Online — {health['chunks_indexed']} chunks indexed")
    except Exception:
        st.error("Backend unreachable")
    st.markdown("---")
    st.caption(
        "Ask about password resets, VPN, printers, mobile email setup, "
        "software requests, backups, or Wi-Fi access."
    )

if "messages" not in st.session_state:
    st.session_state.messages = []

for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        if msg.get("sources"):
            st.caption("Sources: " + ", ".join(msg["sources"]))

question = st.chat_input("Ask a question about IT helpdesk topics...")

if question:
    st.session_state.messages.append({"role": "user", "content": question})
    with st.chat_message("user"):
        st.markdown(question)

    with st.chat_message("assistant"):
        with st.spinner("Retrieving context and generating an answer..."):
            try:
                result = ask_question(question)
                answer = result["answer"]
                sources = result.get("sources", [])
                st.markdown(answer)
                if sources:
                    st.caption("Sources: " + ", ".join(sources))
                st.session_state.messages.append(
                    {"role": "assistant", "content": answer, "sources": sources}
                )
            except ApiError as e:
                error_msg = f"⚠️ {e}"
                st.error(error_msg)
                st.session_state.messages.append({"role": "assistant", "content": error_msg})
